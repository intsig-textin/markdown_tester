def titleAdapter(input_md):
    return input_md


def gt_TitleAdapter(input_md, run_type, special_mark='@@@@@'):
    res_md = ''
    md_item_list = input_md.split('\n\n')
    for i, md_item in enumerate(md_item_list):
        if md_item.startswith(special_mark):
            if run_type == 'pred':
                md_item = md_item[len(special_mark):]
                md_item = '###### ' + md_item.strip()
            else:
                md_item = md_item[len(special_mark):]
                md_item = md_item.strip()
        res_md += md_item + '\n\n'
    if res_md:
        res_md = res_md[:-2]
    return res_md


def gtAdapter(input_md, run_type):
    md = gt_TitleAdapter(input_md, run_type)
    return md
