import os

import html
import unicodedata
import sys
import re
sys.path.append( os.path.dirname(__file__) + "/../../table_evaluation")
from html_to_metric.metric import TEDS
import Levenshtein
from bs4 import BeautifulSoup
from tester.text_evaluation.text_evaluation import get_edit_distance_score

def fetch_result_table_json(pred_md):
    """
    pred_md format edit
    """
    # pred_md = pred_md["result"]["markdown"]
    pred_md = pred_md.split("\n\n")
    table_flow = []
    table_flow_no_space = []
    for idx, md_i in enumerate(pred_md):
        if '<table' in md_i.replace(" ","").replace("'",'"'):
            table_res = html.unescape(md_i).replace('\\', '').replace('\n', '')
            table_res = unicodedata.normalize('NFKC', table_res).strip()
            table_res = re.sub('<table.*?>','',table_res)
            table_res = re.sub('</?tbody>','',table_res)
            table_res = re.sub('( style=".*?")', "", table_res)
            table_res = re.sub('( height=".*?")', "", table_res)
            table_res = re.sub('( width=".*?")', "", table_res)
            table_res = re.sub('( align=".*?")', "", table_res)
            table_res = re.sub('( class=".*?")', "", table_res)
            table_res_no_space = '<html><body><table border="1" >' + table_res.replace(' ','') + '</body></html>'
            # table_res_no_space = re.sub(' (style=".*?")',"",table_res_no_space)
            table_res_no_space = re.sub(r'[ $]', "", table_res_no_space)
            table_res_no_space = re.sub('colspan="', ' colspan="', table_res_no_space)
            table_res_no_space = re.sub('rowspan="', ' rowspan="', table_res_no_space)
            table_res_no_space = re.sub('border="', ' border="', table_res_no_space)

            table_res = '<html><body>' + table_res + '</body></html>'
            table_flow.append(table_res)
            table_flow_no_space.append(table_res_no_space)
    return table_flow, table_flow_no_space


def clean_pred_table_text(text):
    text = re.sub('\*\*(.*?)\*\*',lambda x:x.group(1),text)
    return text
def clean_text(input_str,flag=True):
    if flag:
        input_str = input_str.replace('一', '-').replace('—', '-').replace('·', '•').replace(' ', '')
        input_str = input_str.replace('•', '·')
        input_str = input_str.replace('-', '')
    return input_str
def clean_table(input_str,flag=True):
    if flag:
        input_str = input_str.replace('<sup>', '').replace('</sup>', '')
        input_str = input_str.replace('<sub>', '').replace('</sub>', '')
        input_str = input_str.replace('<span>', '').replace('</span>', '')
        input_str = input_str.replace('<div>', '').replace('</div>', '')
        input_str = input_str.replace('<p>', '').replace('</p>', '')
        input_str = input_str.replace('<spandata-span-identity="">', '')
    return input_str
def eval_by_table(pred, gt):
    gt_socre = [0.0] * len(gt)
    table_num = len(gt)
    pred_arr = []
    gt_arr = []
    if len(gt) > 0 and len(pred) > 0:
        gt_cell_total = [None] * len(gt)
        pred_cell_total = [None] * len(pred)

        for idx, table_g in enumerate(gt):
            table_g = BeautifulSoup(table_g, 'html.parser').prettify()
            gt_str = re.findall('>(.*?)<', table_g.replace('\xa0', ''))
            gt_str = [g_s for g_s in gt_str if g_s]
            gt_cell_total[idx] = gt_str
            gt_arr.append(''.join(gt_str))

        for idx, table_p in enumerate(pred):
            table_p = BeautifulSoup(table_p, 'html.parser').prettify()
            pred_str = re.findall('>(.*?)<', table_p.replace('\xa0', ''))
            pred_str = [clean_pred_table_text(p_s) for p_s in pred_str]
            pred_str = [p_s for p_s in pred_str if p_s]
            pred_cell_total[idx] = pred_str
            pred_arr.append(''.join(pred_str))
        # 按表格中文本的最小编辑距离，match pred 与GT
        match_array = [[Levenshtein.distance(''.join(p), ''.join(g)) for p in pred_cell_total] for g in gt_cell_total]
        # match_array = np.array(match_array)
        # 按照文本编辑距离取框
        # match_pred_index = np.argmin(match_array, axis=0).tolist()
        mini_data = [min(data) for data in match_array]
        match_pred_index = [match_array[i].index(data) for i,data in enumerate(mini_data)]
        for gt_index, pred_index in enumerate(match_pred_index):
            if clean_text(pred_arr[pred_index]) == clean_text(gt_arr[gt_index]):
                gt_socre[gt_index] = 1.0

    if table_num > 0:
        eval_res = sum(gt_socre)/table_num

    return table_num,gt_socre




def eval_by_Teds_match(pred, gt):
    """
    将pred和gt中的表格进行匹配
    如果

    """
    def strcut_clean(input_str):
        input_str = re.sub('<colgroup>.*?</colgroup>','',input_str)
        return input_str
    gt_socre = [0.0] * len(gt)
    total_score = 0.0
    table_num = len(gt)
    teds = TEDS(structure_only=False)

    if len(gt) > 0 and len(pred) > 0:
        gt_cell_total = [None] * len(gt)
        pred_cell_total = [None] * len(pred)

        for idx, table_g in enumerate(gt):
            gt_str = re.findall('>(.*?)<', table_g.replace('\xa0', ''))
            gt_str = [g_s for g_s in gt_str if g_s]
            gt_cell_total[idx] = gt_str

        for idx, table_p in enumerate(pred):
            pred_str = re.findall('>(.*?)<', table_p.replace('\xa0', ''))
            pred_str = [p_s for p_s in pred_str if p_s]
            pred_cell_total[idx] = pred_str
        # 按表格中文本的最小编辑距离，match pred 与GT
        match_array = [[Levenshtein.distance(''.join(p), ''.join(g)) for p in pred_cell_total] for g in gt_cell_total]
        # match_array = np.array(match_array)
        # 按照文本编辑距离取框
        # match_pred_index = np.argmin(match_array, axis=0).tolist()
        mini_data = [min(data) for data in match_array]
        match_pred_index = [match_array[i].index(data) for i,data in enumerate(mini_data)]
        for gt_index, pred_index in enumerate(match_pred_index):
            if gt_socre[gt_index] == 0.0:
                gt_socre[gt_index] = max(0.0, teds.evaluate(strcut_clean(pred[pred_index]), strcut_clean(clean_table(gt[gt_index]))))
            else:
                gt_socre[gt_index] = max(gt_socre[gt_index], teds.evaluate(strcut_clean(pred[pred_index]), strcut_clean(clean_table(gt[gt_index]))))

    if table_num > 0:
        total_score = sum(gt_socre) / table_num

    return total_score, gt_socre
def get_table_struct(table_str):
    table_str = re.sub('<table.*?>','<table>',table_str)
    table_str = re.sub('<tr.*?>','<tr>',table_str)
    table_str = re.sub('<td.*?>','<td>',table_str)
    table_str = re.sub('<td>.*?</td>','<td>-</td>',table_str)
    return table_str
def eval_by_struct_Teds_match(pred, gt):
    def strcut_clean(input_str):
        input_str = re.sub('<colgroup>.*?</colgroup>','',input_str)
        return input_str
    """
    将pred和gt中的表格进行匹配
    如果

    """

    gt_socre = [0.0] * len(gt)
    total_score = 0.0
    table_num = len(gt)
    teds = TEDS(structure_only=False)

    if len(gt) > 0 and len(pred) > 0:
        gt_cell_total = [None] * len(gt)
        pred_cell_total = [None] * len(pred)

        for idx, table_g in enumerate(gt):
            gt_str = re.findall('>(.*?)<', table_g.replace('\xa0', ''))
            gt_str = [g_s for g_s in gt_str if g_s]
            gt_cell_total[idx] = gt_str

        for idx, table_p in enumerate(pred):
            pred_str = re.findall('>(.*?)<', table_p.replace('\xa0', ''))
            pred_str = [p_s for p_s in pred_str if p_s]
            pred_cell_total[idx] = pred_str
        # 按表格中文本的最小编辑距离，match pred 与GT
        match_array = [[Levenshtein.distance(''.join(p), ''.join(g)) for p in pred_cell_total] for g in gt_cell_total]
        mini_data = [min(data) for data in match_array]
        match_pred_index = [match_array[i].index(data) for i,data in enumerate(mini_data)]
        pred = [get_table_struct(table_str) for table_str in pred]
        gt = [get_table_struct(table_str) for table_str in gt]
        for gt_index, pred_index in enumerate(match_pred_index):
            if gt_socre[gt_index] == 0.0:
                gt_socre[gt_index] = max(0.0, teds.evaluate(strcut_clean(pred[pred_index]), strcut_clean(gt[gt_index])))
            else:
                gt_socre[gt_index] = max(gt_socre[gt_index], teds.evaluate(strcut_clean(pred[pred_index]), strcut_clean(gt[gt_index])))

    if table_num > 0:
        total_score = sum(gt_socre) / table_num

    return total_score, gt_socre

def convert_to_halfwidth(text):
    halfwidth_text = ''
    for char in text:
        if unicodedata.east_asian_width(char) == 'F':  # 判断字符是否为全角符号
            halfwidth_char = unicodedata.normalize('NFKC', char)  # 将全角符号转换为半角符号
            halfwidth_text += halfwidth_char
        else:
            halfwidth_text += char
    return halfwidth_text


def compare_cell_ocr(gt_content,pred_content,need_compare_ocr):
    # 使用正则化把md中的表格都提取出来
    pattern = r'(<table.*?</table>)'
    gt_result_list = re.findall(pattern, gt_content, re.DOTALL)
    pred_result_list_scr = re.findall(pattern, pred_content, re.DOTALL)
    pred_result_list = []
    for gt in gt_result_list:
        gt_str = ''.join(re.findall('>(.*?)<',gt.replace('\n','')))
        max_score = 0
        idx = -1
        for i,pred in enumerate(pred_result_list_scr):
            pred_str = ''.join(re.findall('>(.*?)<',pred.replace('\n','')))
            score = get_edit_distance_score(clean_text(gt_str),clean_text(pred_str))
            if score>max_score:
                max_score = score
                idx = i
        if idx != -1:
            pred_result_list.append(pred_result_list_scr[idx])


    res = [[]]*len(gt_result_list)

    # 遍历gt和pred中的对应表格
    for idx in range(len(gt_result_list)):
        if not need_compare_ocr[idx]:
            continue
        gt_table = gt_result_list[idx]
        pred_table = pred_result_list[idx]

        gt_table = f'<html><body>{gt_table}</body></html>'
        pred_table = f'<html><body>{pred_table}</body></html>'

        # 解析表格并提取表格内容
        gt_soup = BeautifulSoup(gt_table, 'html.parser')
        gt_table = gt_soup.find('table')
        gt_rows = gt_table.find_all('tr')

        pred_soup = BeautifulSoup(pred_table, 'html.parser')
        pred_table = pred_soup.find('table')
        pred_rows = pred_table.find_all('tr')

        gt_data = []
        for row in gt_rows:
            cells = row.find_all('td')
            row_data = [cell.text.strip() for cell in cells]
            gt_data.append(row_data)
        pred_data = []
        for row in pred_rows:
            cells = row.find_all('td')
            row_data = [cell.text.strip() for cell in cells]
            pred_data.append(row_data)

        # 对比看两个表格中，哪些cell中的ocr结果有差异
        for row_idx in range(len(pred_data)):
            gt_row = gt_data[row_idx]
            pred_row = pred_data[row_idx]
            for col_idx in range(len(pred_row)):
                gt_text = gt_row[col_idx]
                pred_text = pred_row[col_idx]
                gt_text = convert_to_halfwidth(gt_text)
                pred_text = convert_to_halfwidth(pred_text)
                gt_text = gt_text.replace(' ', '').replace('\n', '')
                pred_text = pred_text.replace(' ', '').replace('\n', '')
                if gt_text != pred_text:
                    # 在tester中保存有问题ocr结果不一致cell的行列及文本
                    print(f"row_idx = {row_idx}, col_idx = {col_idx}")
                    print(f"gt_text = |{gt_text}|")
                    print(f"pred_te = |{pred_text}|" + '\n')
                    res[idx].append({"row" :row_idx,"col":col_idx,"gt_ocr":gt_text,"pred_ocr":pred_text})
    return res


class Md_Tester(object):
    def __init__(self):
        self.ignore_bold = True
    def __call__(self,raw_meta_json,raw_pred_json):
        """

        """

        if self.ignore_bold:
            tables = re.findall(r'<table[\s\S]*?</table>',raw_pred_json)
            new_tb = [re.sub(r'\*\*(.*?)\*\*',lambda x:x.groups()[0],table) for table in tables]
            for table,clean_table in zip(tables,new_tb):
                raw_pred_json = raw_pred_json.replace(table,clean_table)

        table_pred, table_pred_n_spc = fetch_result_table_json(raw_pred_json)
        table_gt, table_gt_n_spc = fetch_result_table_json(raw_meta_json)
               
        if len(table_gt)>0:
            table_num, eval_res_n_spc = eval_by_table(table_pred_n_spc, table_gt_n_spc)
            _, score_i_n = eval_by_Teds_match(table_pred_n_spc, table_gt_n_spc)
            _,struct_score = eval_by_struct_Teds_match(table_pred_n_spc,table_gt_n_spc)
            need_compare_ocr = []
            for i in range(len(table_gt)):
                if struct_score[i] == 1 and eval_res_n_spc[i] != 1:
                    need_compare_ocr.append(True)
                else:
                    need_compare_ocr.append(False)
            try:
                cell_ocr_res = compare_cell_ocr(raw_meta_json,raw_pred_json,need_compare_ocr)
            except:
                cell_ocr_res = ['error']
        else:
            table_num = 0
            eval_res_n_spc = [0]
            score_i_n = [0]
            struct_score = [0]
            cell_ocr_res = []


        #保存子指标
        child_index = {}
        child_index['compare_cell_ocr'] = cell_ocr_res
        
        return table_num,eval_res_n_spc,score_i_n,struct_score,child_index
