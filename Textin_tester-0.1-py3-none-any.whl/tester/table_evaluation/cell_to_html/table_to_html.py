import numpy as np


def get_html(cells, tokens):
    """Cells(table stucture) and tokens(table content) to get html.

    Args:
        cells (list): table stucture
        tokens (list): table content

    Returns:
        (str): html
    """
    end_html = []
    td_index = 0
    for tag in tokens:
        if '</td>' in tag:
            content = "".join(cells[td_index]['tokens'])
            end_html.extend(content)
            end_html.append(tag)
            td_index += 1
        else:
            end_html.append(tag)
    end_html = ['<html>', '<body>', '<table>'] + end_html + ['</table>', '</body>', '</html>']
    return ''.join(end_html)


def cell_to_html(doc):
    """Cell to html.

    Args:
        doc (Document): Document object
    """
    for table in doc.tables:
        table_html = ['<tr>']
        cells = []
        row_index = 0
        for cell in table.cells:
            if cell.start_row == row_index or cell.start_row == row_index + 1:
                if cell.start_row == row_index + 1:
                    row_index += 1
                    table_html.append('</tr>')
                    table_html.append('<tr>')
                if cell.text == "":
                    temp_dict = {"tokens": []}
                else:
                    pnts = cell.position
                    temp_dict = {"tokens": [cell.text]}
                cells.append(temp_dict)
                colspan = cell.end_col - cell.start_col + 1
                rowspan = cell.end_row - cell.start_row + 1
                if colspan != 1 and rowspan != 1:
                    table_html.append("<td")
                    table_html.append(" colspan=" + str(colspan))
                    table_html.append(" rowspan=" + str(rowspan))
                    table_html.append(">")
                elif colspan == 1 and rowspan != 1:
                    table_html.append("<td")
                    table_html.append(" rowspan=" + str(rowspan))
                    table_html.append(">")
                elif colspan != 1 and rowspan == 1:
                    table_html.append("<td")
                    table_html.append(" colspan=" + str(colspan))
                    table_html.append(">")
                else:
                    table_html.append("<td>")
                table_html.append("</td>")
        table_html.append('</tr>')
        result = get_html(cells, table_html)
        doc.htmls.append(result)
