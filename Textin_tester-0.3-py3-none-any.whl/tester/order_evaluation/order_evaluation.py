from tester.text_evaluation.text_evaluation import check_custom_structure, remove_special_chars, get_edit_distance_score
import re
import Levenshtein




def need_move_text(text,remove_arr):
    if not remove_arr:
        return False
    score = max([compute_score_by_ed(text,rm) for rm in remove_arr])
    th = 0.95
    if score>=th:
        return True
    else:
        return False

def extract_pred_in_order(pred_json,remove_arr):
    texts = pred_json.split('\n\n')
    res = []
    for text in texts:
        text = text.strip()
        text = text.lstrip('\n')
        if text:  # Check if the stripped text is not empty
            if text.startswith('<table') and text.endswith('</table>'):
                res.append(text)
            elif text.startswith('#') and '\n' not in text:
                if not need_move_text(remove_special_chars(text.lstrip('#').strip()),remove_arr):
                    res.append(remove_special_chars(text.lstrip('#').strip()))
            elif text.startswith('$'):
                pass
            else:
                if not check_custom_structure(text) and not need_move_text(remove_special_chars(text),remove_arr):
                    res.append(remove_special_chars(text))

    return res

def get_text_and_table(arr):
    text = ''
    tables = []
    all_len = 0
    times = 0
    for item in arr:
        if item.startswith('<table'):
            tables.append(item)
            text += "<#table>"
            all_len += len(f"<table>{str(len(tables))}")
        else:
            text += item
            all_len += len(item)
        times += 1
    if times>0:
        avg_len = int(all_len/times)
    else:
        avg_len = 0 
    return text,tables,avg_len


def compute_score_by_ed(str1,str2):
    if len(str1) == 0 and len(str2) == 0:
        return 1
    score = 1-Levenshtein.distance(str1,str2)/(len(str1)+len(str2))
    return score
        
def extract_objects_from_string(s):
    texts = s.split('\n\n')
    objects = []
    
    for text in texts:
        text = text.strip()
        text = text.lstrip('\n')
        if text: #Check if the stripped text is not empty
            if text.startswith('<table') and text.endswith('</table>'):
                objects.append([text, 'table'])
            elif text.startswith('#') and '\n' not in text:
                objects.append([text, 'title'])
            elif text.startswith('$'):
                objects.append([text, 'formula'])
            else:
                objects.append([text, 'text'])

    return objects


class OrderEval(object):
    def __init__(self) -> None:
        self.threshold = 1.0
        self.threshold_bl = 0.8
        pass

    
    def sentence_similar(self,sentence1,sentence2):
        similar_score = compute_score_by_ed(sentence1, sentence2)
        return similar_score

    def __call__(self, raw_meta_json, raw_pred_json) -> dict:
        order_res = {}


        gt_objects = extract_objects_from_string(raw_meta_json)
        pred_objects = extract_objects_from_string(raw_pred_json)




        score = self.compute_order_score(gt_objects, pred_objects)
        order_res['order_score'] = score
        
        return order_res
    
    def compare_two_objects(self, gt_obj, pred_obj):
        threshold = 0.9
        if pred_obj[1] == gt_obj[1]:
            pred_text = remove_special_chars(pred_obj[0])
            gt_text = remove_special_chars(gt_obj[0])
            score = get_edit_distance_score(pred_text, gt_text)
            if score > threshold:
                return True
            else:
                return False

    def object_2_string(self, item):
        item[0] = remove_special_chars(item[0])
        if item[1] == 'table':
            the_list = re.findall('>(.*?)<', item[0].replace('\xa0', '')) #extract only table info
            item[0] = ''.join(the_list)

    def compute_order_score(self, gt_objects, pred_objects):
        threshold = 0.8

        for gt_object in gt_objects:
            self.object_2_string(gt_object)

        for pred_object in pred_objects:
            self.object_2_string(pred_object)
        
        matched_gt_set = set()
        gt_objects_ = gt_objects.copy()
        for pred_object in pred_objects:
            best_score = 0
            matched_gt_text = None
            pred = pred_object[0]
            index_ = None
            for index, gt_object in enumerate(gt_objects):
                gt = gt_object[0]
                # #print('gt object is {}'.format(gt))
                if gt in matched_gt_set:
                    continue
                if pred_object[1] == gt_object[1]:  # 类型相同
                    score = get_edit_distance_score(pred, gt)
                    # #print('score is {}'.format(score))
                    # find best gt
                    if score > best_score and score > threshold:
                        best_score = score
                        matched_gt_text = gt
                        index_ = index
            if matched_gt_text is not None:
                gt_objects.pop(index_)
                pred_object[0] = matched_gt_text
            else:
                pred_object[0] = ''

        pred_all_text = ''
        gt_all_text = ''

        for pred_object in pred_objects:
            pred_all_text += pred_object[0]

        for gt_object in gt_objects_:
            gt_all_text += gt_object[0]

        order_score = get_edit_distance_score(pred_all_text, gt_all_text)

        return order_score
        